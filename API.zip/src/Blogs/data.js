const BlogData = [
    {
        type: "fashion",
        img: '/assets/images/blog/1.jpg',
        link: '/blog/details',
        title: '25 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/assets/images/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/assets/images/blog/3.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/assets/images/blog/4.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/assets/images/blog/5.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "fashion",
        img: '/assets/images/blog/6.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/assets/images/beauty/blog/1.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/assets/images/beauty/blog/2.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/assets/images/beauty/blog/3.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "beauty",
        img: '/assets/images/beauty/blog/4.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment',
        shortDesc: 'you how all this mistaken idea of denouncing pleasure and praising pain was born',
        longDesc: 'Consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.'
    },
    {
        type: "pets",
        img: '/assets/images/pets/blog/1.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/assets/images/pets/blog/2.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/assets/images/pets/blog/3.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "pets",
        img: '/assets/images/pets/blog/4.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/assets/images/blog/layout3/1.jpg',
        link: '/blog/details',
        title: '25 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/assets/images/blog/layout3/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/assets/images/blog/layout3/3.jpg',
        link: '/blog/details',
        title: '29 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/assets/images/blog/layout3/4.jpg',
        link: '/blog/details',
        title: '25 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "bags",
        img: '/assets/images/blog/layout3/5.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "flower",
        img: '/assets/images/flower/blog/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "flower",
        img: '/assets/images/flower/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "flower",
        img: '/assets/images/flower/blog/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/assets/images/furniture/blog1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/assets/images/furniture/blog2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/assets/images/furniture/blog3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "furniture",
        img: '/assets/images/furniture/selk.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "vegetables",
        img: '/assets/images/vegetables/blog/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/assets/images/vegetables/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/assets/images/vegetables/blog/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }, {
        type: "vegetables",
        img: '/assets/images/vegetables/blog/4.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/assets/images/blog/layout2/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/assets/images/blog/layout2/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/assets/images/blog/layout2/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/assets/images/blog/layout2/4.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "shoes",
        img: '/assets/images/blog/layout2/5.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/assets/images/nursery/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/assets/images/nursery/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "nursery",
        img: '/assets/images/nursery/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/assets/images/gym/blog/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/assets/images/gym/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/assets/images/gym/blog/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/assets/images/gym/blog/4.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "gym",
        img: '/assets/images/gym/blog/5.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/assets/images/marijuana/blog/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/assets/images/marijuana/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "marijuana",
        img: '/assets/images/marijuana/blog/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/assets/images/blog/layout4/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/assets/images/blog/layout4/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/assets/images/blog/layout4/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/assets/images/blog/layout4/4.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "watch",
        img: '/assets/images/blog/layout4/5.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/1.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/7.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/2.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/3.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/4.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/5.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/6.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    },
    {
        type: "christmas",
        img: '/assets/images/christmas/blog/7.jpg',
        link: '/blog/details',
        title: '26 January 2018',
        desc: 'Lorem ipsum dolor sit consectetur adipiscing elit',
        date: 'by: John Dio , 2 Comment'
    }
]

module.exports = BlogData;
